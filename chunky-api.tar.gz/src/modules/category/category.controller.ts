import { Request, Response } from "express";
import { getAllCategories } from "./category.service";

export const getCategories = async (_req: Request, res: Response) => {
    try {
        const response = await getAllCategories(
            process.env.LOYVERSE_BASE_URL || "",
            process.env.LOYVERSE_TOKEN || ""
        );

        return res.json({
            code: 200,
            data: response,
        });
    } catch (e: any) {
        res.status(500).json({ message: e.message ?? "Server error" });
    }
}

/* export const setCategory = async (_req: Request, res: Response) => {
    try {
        const responnse = await createCategory(_req.body);

        res.json({
            ok: true,
            data: responnse,
        });
    } catch (error) {
        console.error(error);
        res.status(500).json({
            ok: false,
            message: "Error creating category",
        });
    }
} */