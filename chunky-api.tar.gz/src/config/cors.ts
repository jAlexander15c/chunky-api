import cors from "cors";

export const corsConfig = cors({
  origin: [
    "http://localhost:5173",
    "https://chunkybites.com",
  ],
  methods: ["GET", "POST", "PUT", "DELETE"],
  credentials: true,
});
