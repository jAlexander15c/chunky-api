import { cached } from '../../utils/cache';

export const getItemService = async (baseURL: string, token: string, itemId?: string) => {
    try {
        const response = await fetch(`${baseURL}/items${itemId ? `/${itemId}` : ""}`, {
            headers: {
                Authorization: `Bearer ${token}`,
            },
        });

        if (response.status !== 200) {
            return await response.json();
        }

        const data = await response.json();
        return data;
    } catch (error: any) {
        console.error("Error fetching items:", error.message);
        throw new Error("Failed to fetch items");
    }
};

const TTL_MS = 2 * 60 * 1000; // 2 min (ajusta a 60–300s según cuánto cambies menú)
const ALL_ITEMS_CACHE_KEY = 'items:all';

const normalizeItems = (resp: any) => {
    if (Array.isArray(resp)) return resp;
    return resp?.items ?? [];
};

const fetchAllItemsFromLoyverse = async () => {
    const baseUrl = process.env.LOYVERSE_BASE_URL || 'https://api.loyverse.com/v1.0';
    const token = process.env.LOYVERSE_TOKEN;

    if (!token) throw new Error('Missing env: LOYVERSE_TOKEN');

    const res = await fetch(`${baseUrl}/items`, {
        headers: { Authorization: `Bearer ${token}` },
    });

    if (!res.ok) {
        const text = await res.text();
        throw new Error(`Loyverse error ${res.status}: ${text}`);
    }

    const data = await res.json();
    return normalizeItems(data);
};

export const getItemsByCategoryIdService = async (categoryId: string) => {
  if (!categoryId?.trim()) throw new Error('categoryId is required');

  // 1) Trae todos los items desde cache (o Loyverse si expiró)
  const allItems = await cached(ALL_ITEMS_CACHE_KEY, TTL_MS, fetchAllItemsFromLoyverse);

  // 2) Filtra por category_id (rápido, en memoria)
  return allItems.filter((it: any) => it.category_id === categoryId);
};
