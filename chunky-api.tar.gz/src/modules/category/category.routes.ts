import { Router } from "express";
import { getCategories } from "./category.controller";
import { apiKeyGuard } from "../../middlewares/apiKey.middleware";

const router = Router();

router.get("/get-categories", getCategories);

export default router;