import express from "express";
import categoryRoutes from "./modules/category/category.routes";
import itemRoutes from "./modules/items/item.routes";
import helmet from "helmet";
import { corsConfig } from "./config/cors";
import { apiLimiter } from "./config/rateLimit";
import 'dotenv/config';

const app = express();

app.use(
    helmet({
        crossOriginResourcePolicy: false,
    })
);
app.use(corsConfig);
app.use(apiLimiter);

app.use(express.json());

app.get("/health", (_req, res) => res.status(200).send("ok"));
app.use("/categories", categoryRoutes);
app.use("/items", itemRoutes);

export default app;
