import { prisma } from "../../prisma/client";

export const getAllCategories = async (baseURL: string, token: string) => {
    try {
        const response = await fetch(`${baseURL}/categories`, {
            headers: {
                Authorization: `Bearer ${token}`,
            },
        });

        if (response.status !== 200) {
            return await response.json();
        }

        const data = await response.json();
        return data;
    } catch (error: any) {
        console.error("Error fetching categories:", error.message);
        throw new Error("Failed to fetch categories");
    }
};

type CreateCategoryInput = {
    name: string;
    description: string;
    imageSrc: string; // aquí guardas el URL o key de R2 (ej: "categories/cookies.webp")
};

export const createCategory = async (input: CreateCategoryInput) => {
    // Validación mínima (puedes hacerla con zod si quieres)
    if (!input.name?.trim()) throw new Error("Category name is required");
    if (!input.description?.trim()) throw new Error("Category description is required");
    if (!input.imageSrc?.trim()) throw new Error("Category imageSrc is required");

    // Si quieres evitar duplicados por nombre:
    // (requiere un @unique en Category.name para que sea perfecto)
    const existing = await prisma.category.findFirst({
        where: { name: input.name.trim() },
        select: { id: true },
    });
    if (existing) throw new Error("Category with this name already exists");

    const category = await prisma.category.create({
        data: {
            name: input.name.trim(),
            description: input.description.trim(),
            imageSrc: input.imageSrc.trim(),
        },
        // opcional: si quieres devolver la categoría con sus productos (vacío al inicio)
        include: { products: true },
    });

    return category;
}