import { Router } from "express";
import { getItems, getItemById } from "./item.controller";
import { apiKeyGuard } from "../../middlewares/apiKey.middleware";

const router = Router();

router.get("/get-items/:id", getItemById);
router.get("/get-items", getItems)


export default router;