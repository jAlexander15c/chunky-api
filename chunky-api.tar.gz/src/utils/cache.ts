type CacheEntry<T> = { value: T; expiresAt: number };

const store = new Map<string, CacheEntry<any>>();
const inflight = new Map<string, Promise<any>>();

export async function cached<T>(
  key: string,
  ttlMs: number,
  loader: () => Promise<T>
): Promise<T> {
  const now = Date.now();
  const hit = store.get(key);
  if (hit && hit.expiresAt > now) return hit.value;

  // evita que 20 requests simultáneos disparen 20 llamadas a Loyverse
  const pending = inflight.get(key);
  if (pending) return pending;

  const p = (async () => {
    const value = await loader();
    store.set(key, { value, expiresAt: now + ttlMs });
    return value;
  })().finally(() => {
    inflight.delete(key);
  });

  inflight.set(key, p);
  return p;
}