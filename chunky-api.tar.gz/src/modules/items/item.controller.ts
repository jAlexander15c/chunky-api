import { Request, Response } from "express";
import { getItemService, getItemsByCategoryIdService } from "./item.service";

export const getItemById = async (req: Request, res: Response) => {
    try {
        const { id } = req.params;

        const item = await getItemService(process.env.LOYVERSE_BASE_URL || '', process.env.LOYVERSE_TOKEN || '',id);
        if (!item) return res.status(404).json({ message: "Item not found" });

        return res.json(item);
    } catch (err: any) {
        return res.status(500).json({ message: err?.message ?? "Server error" });
    }
};

export const getItems = async (req: Request, res: Response) => {
    try {
        const { category_id } = req.query;
        console.log('category_id:', category_id);

        if (category_id) {
            const items = await getItemsByCategoryIdService(String(category_id));
            return res.json(items);
        }

        const items = await getItemService(process.env.LOYVERSE_BASE_URL || '', process.env.LOYVERSE_TOKEN || '');
        return res.json(items);
    } catch (err: any) {
        return res.status(500).json({ message: err?.message ?? "Server error" });
    }
};